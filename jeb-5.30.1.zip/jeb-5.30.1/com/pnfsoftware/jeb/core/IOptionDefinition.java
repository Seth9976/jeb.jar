package com.pnfsoftware.jeb.core;

public interface IOptionDefinition {
   String getDescription();

   String getName();

   String getDefaultValue();
}
