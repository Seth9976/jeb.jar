package com.pnfsoftware.jeb.core.exceptions;

public class UnmanglerException extends JebRuntimeException {
   private static final long serialVersionUID = 1L;

   public UnmanglerException() {
   }

   public UnmanglerException(String var1) {
      super(var1);
   }
}
