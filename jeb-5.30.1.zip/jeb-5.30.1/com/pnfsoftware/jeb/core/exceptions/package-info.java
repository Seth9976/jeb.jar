package com.pnfsoftware.jeb.core.exceptions;

interface package-info {
}
