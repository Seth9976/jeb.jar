package com.pnfsoftware.jeb.core.exceptions;

public class NotImplementedException extends JebException {
   private static final long serialVersionUID = 1L;

   public NotImplementedException() {
   }

   public NotImplementedException(String var1) {
      super(var1);
   }
}
