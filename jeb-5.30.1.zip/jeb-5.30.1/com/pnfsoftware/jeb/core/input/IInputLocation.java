package com.pnfsoftware.jeb.core.input;

public interface IInputLocation {
}
