package com.pnfsoftware.jeb.core;

public class JebClientInformation {
   private String clientSignature;

   public JebClientInformation(String var1) {
      this.clientSignature = var1;
   }

   public String getClientSignature() {
      return this.clientSignature;
   }
}
