package com.pnfsoftware.jeb.core.dao.impl;

interface package-info {
}
