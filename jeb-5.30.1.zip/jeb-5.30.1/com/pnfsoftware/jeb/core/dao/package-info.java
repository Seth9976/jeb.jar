package com.pnfsoftware.jeb.core.dao;

interface package-info {
}
