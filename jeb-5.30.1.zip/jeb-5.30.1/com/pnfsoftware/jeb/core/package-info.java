package com.pnfsoftware.jeb.core;

interface package-info {
}
