package com.pnfsoftware.jeb.core.units.code.android.dex;

public enum DexPoolType {
   STRING,
   TYPE,
   PROTOTYPE,
   FIELD,
   METHOD,
   CLASS,
   METHOD_HANDLE,
   CALL_SITE;
}
