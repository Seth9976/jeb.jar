package com.pnfsoftware.jeb.core.units.code.android.ir;

public enum DOptimizerType {
   NORMAL,
   UNSAFE,
   CUSTOM;
}
