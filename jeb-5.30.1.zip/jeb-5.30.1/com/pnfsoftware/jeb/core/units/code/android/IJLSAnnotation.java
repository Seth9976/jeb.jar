package com.pnfsoftware.jeb.core.units.code.android;

import java.util.Map;

public interface IJLSAnnotation {
   String getType();

   Map getValues();
}
