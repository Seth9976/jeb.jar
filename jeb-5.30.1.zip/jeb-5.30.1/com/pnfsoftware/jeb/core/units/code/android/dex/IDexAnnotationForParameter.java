package com.pnfsoftware.jeb.core.units.code.android.dex;

import java.util.List;

public interface IDexAnnotationForParameter {
   int getMethodIndex();

   List getAnnotationItemSets();
}
