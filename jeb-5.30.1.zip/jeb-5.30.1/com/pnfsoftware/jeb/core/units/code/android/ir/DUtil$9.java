package com.pnfsoftware.jeb.core.units.code.android.ir;

// $VF: synthetic class
class DUtil$9 {
   static {
      try {
         $SwitchMap$com$pnfsoftware$jeb$core$units$code$android$ir$DOpcodeType[DOpcodeType.IR_JCOND.ordinal()] = 1;
      } catch (NoSuchFieldError var1) {
      }

      try {
         $SwitchMap$com$pnfsoftware$jeb$core$units$code$android$ir$DOpcodeType[DOpcodeType.IR_SWITCH.ordinal()] = 2;
      } catch (NoSuchFieldError var0) {
      }
   }
}
