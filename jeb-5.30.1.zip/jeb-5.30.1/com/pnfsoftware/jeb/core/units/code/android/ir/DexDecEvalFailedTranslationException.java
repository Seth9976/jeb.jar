package com.pnfsoftware.jeb.core.units.code.android.ir;

public class DexDecEvalFailedTranslationException extends DexDecEvaluationException {
   private static final long serialVersionUID = 1L;

   public DexDecEvalFailedTranslationException(DexDecConversionException var1) {
      super(var1);
   }
}
