package com.pnfsoftware.jeb.core.units.code.android;

enum IDalvikDebuggerUnit$ThreadFrameSlotIndexMode$1 {
   @Override
   public String toString() {
      return "Automatic";
   }
}
