package com.pnfsoftware.jeb.core.units.code.android.ir;

public interface IDNewInfo extends IDCallInfo {
   IDNewInfo duplicate();
}
