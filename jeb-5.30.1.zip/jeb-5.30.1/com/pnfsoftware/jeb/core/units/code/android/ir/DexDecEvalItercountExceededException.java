package com.pnfsoftware.jeb.core.units.code.android.ir;

public class DexDecEvalItercountExceededException extends DexDecEvaluationException {
   private static final long serialVersionUID = 1L;

   public DexDecEvalItercountExceededException() {
   }

   public DexDecEvalItercountExceededException(String var1) {
      super(var1);
   }
}
