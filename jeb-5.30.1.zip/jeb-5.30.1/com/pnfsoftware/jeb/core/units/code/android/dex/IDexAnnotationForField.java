package com.pnfsoftware.jeb.core.units.code.android.dex;

import java.util.List;

public interface IDexAnnotationForField {
   int getFieldIndex();

   List getAnnotationItems();
}
