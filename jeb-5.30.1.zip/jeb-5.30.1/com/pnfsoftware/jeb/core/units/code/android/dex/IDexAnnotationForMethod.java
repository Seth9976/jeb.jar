package com.pnfsoftware.jeb.core.units.code.android.dex;

import java.util.List;

public interface IDexAnnotationForMethod {
   int getMethodIndex();

   List getAnnotationItems();
}
