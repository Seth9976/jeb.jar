package com.pnfsoftware.jeb.core.units.code.android.ir;

public interface IDIndex extends IDElement {
   int getValue();

   IDIndex duplicate();
}
