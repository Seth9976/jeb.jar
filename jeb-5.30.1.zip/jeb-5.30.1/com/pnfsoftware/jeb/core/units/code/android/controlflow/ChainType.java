package com.pnfsoftware.jeb.core.units.code.android.controlflow;

public enum ChainType {
   DU,
   UD;
}
