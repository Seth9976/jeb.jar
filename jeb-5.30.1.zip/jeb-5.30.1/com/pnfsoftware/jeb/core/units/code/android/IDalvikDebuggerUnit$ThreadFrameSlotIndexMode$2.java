package com.pnfsoftware.jeb.core.units.code.android;

enum IDalvikDebuggerUnit$ThreadFrameSlotIndexMode$2 {
   @Override
   public String toString() {
      return "Parameter index (pX)";
   }
}
