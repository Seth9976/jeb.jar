package com.pnfsoftware.jeb.core.units.code.android.ir;

public interface IDEmuClass {
   boolean isInternal();

   String getFullName();

   boolean isInitialized();
}
