package com.pnfsoftware.jeb.core.units.code.android.ir;

public class DexDecEvalUnmanagedCodeException extends DexDecEvaluationException {
   private static final long serialVersionUID = 1L;

   public DexDecEvalUnmanagedCodeException(Throwable var1) {
      super(var1);
   }
}
