package com.pnfsoftware.jeb.core.units.code.android.dex;

public interface IDalvikInstructionSwitchData {
   int getOffset();

   int[][] getElements();
}
