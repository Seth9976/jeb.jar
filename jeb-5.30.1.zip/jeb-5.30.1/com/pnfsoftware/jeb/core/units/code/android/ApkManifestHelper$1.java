package com.pnfsoftware.jeb.core.units.code.android;

// $VF: synthetic class
class ApkManifestHelper$1 {
   static {
      try {
         $SwitchMap$com$pnfsoftware$jeb$core$units$code$android$ApkManifestHelper$EndPointType[ApkManifestHelper.EndPointType.ACTIVITY.ordinal()] = 1;
      } catch (NoSuchFieldError var3) {
      }

      try {
         $SwitchMap$com$pnfsoftware$jeb$core$units$code$android$ApkManifestHelper$EndPointType[ApkManifestHelper.EndPointType.SERVICE.ordinal()] = 2;
      } catch (NoSuchFieldError var2) {
      }

      try {
         $SwitchMap$com$pnfsoftware$jeb$core$units$code$android$ApkManifestHelper$EndPointType[ApkManifestHelper.EndPointType.RECEIVER.ordinal()] = 3;
      } catch (NoSuchFieldError var1) {
      }

      try {
         $SwitchMap$com$pnfsoftware$jeb$core$units$code$android$ApkManifestHelper$EndPointType[ApkManifestHelper.EndPointType.PROVIDER.ordinal()] = 4;
      } catch (NoSuchFieldError var0) {
      }
   }
}
