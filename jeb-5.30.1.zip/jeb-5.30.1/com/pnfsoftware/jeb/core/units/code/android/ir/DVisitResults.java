package com.pnfsoftware.jeb.core.units.code.android.ir;

import com.pnfsoftware.jeb.core.units.code.AbstractVisitResults;

public class DVisitResults extends AbstractVisitResults {
   public DVisitResults() {
   }

   public DVisitResults(int var1) {
      super(var1);
   }
}
