package com.pnfsoftware.jeb.core.events;

interface package-info {
}
