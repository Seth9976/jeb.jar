package com.pnfsoftware.jeb.core.events;

public class QuestionNotificationYesNo extends AbstractQuestionNotification {
   public QuestionNotificationYesNo(String var1, boolean var2) {
      super(var1, var2, false);
   }

   public QuestionNotificationYesNo(String var1, boolean var2, boolean var3) {
      super(var1, var2, var3);
   }
}
