package com.pnfsoftware.jeb.core.events;

public class ControllerNotification {
   public boolean processed;
   public long ctlCode;
   public int ctlHintContinueLeft;
   public int clientChoice;
}
