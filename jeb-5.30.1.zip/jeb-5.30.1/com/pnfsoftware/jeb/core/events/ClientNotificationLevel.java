package com.pnfsoftware.jeb.core.events;

public enum ClientNotificationLevel {
   INFO,
   WARNING,
   ERROR;
}
