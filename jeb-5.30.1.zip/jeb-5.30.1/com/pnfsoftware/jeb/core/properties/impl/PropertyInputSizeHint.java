package com.pnfsoftware.jeb.core.properties.impl;

public enum PropertyInputSizeHint {
   TINY,
   SMALL,
   MEDIUM,
   LARGE,
   EXTRA;
}
