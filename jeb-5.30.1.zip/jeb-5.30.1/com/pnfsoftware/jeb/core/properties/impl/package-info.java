package com.pnfsoftware.jeb.core.properties.impl;

interface package-info {
}
