package com.pnfsoftware.jeb.core.properties;

interface package-info {
}
