package com.pnfsoftware.jeb.core.output;

public enum AddressConversionPrecision {
   DEFAULT,
   COARSE,
   FINE;
}
