package com.pnfsoftware.jeb.core.output.text;

import com.pnfsoftware.jeb.core.output.IVisualItem;

public interface IVisualTextItem extends IVisualItem, ITextItem {
}
