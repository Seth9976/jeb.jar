package com.pnfsoftware.jeb.core.output.text.impl;

interface package-info {
}
