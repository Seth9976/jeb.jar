package com.pnfsoftware.jeb.core.output.tree;

import java.util.List;

public interface INodeCoordinates {
   List getPath();
}
