package com.pnfsoftware.jeb.core.output.tree.impl;

interface package-info {
}
