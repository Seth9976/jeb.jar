package com.pnfsoftware.jeb.core.output;

public interface IVisualItem {
   ItemClassIdentifiers getClassId();
}
