package com.pnfsoftware.jeb.core.output.table;

import com.pnfsoftware.jeb.core.output.IActionableItem;

public interface IActionableCell extends IActionableItem, IVisualCell {
}
