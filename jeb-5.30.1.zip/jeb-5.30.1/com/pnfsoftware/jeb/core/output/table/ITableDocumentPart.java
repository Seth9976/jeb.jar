package com.pnfsoftware.jeb.core.output.table;

import java.util.List;

public interface ITableDocumentPart {
   int getFirstRowIndex();

   List getRows();
}
