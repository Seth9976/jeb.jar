package com.pnfsoftware.jeb.core.output.table;

import com.pnfsoftware.jeb.core.output.IVisualItem;

public interface IVisualCell extends IVisualItem, ICell {
}
