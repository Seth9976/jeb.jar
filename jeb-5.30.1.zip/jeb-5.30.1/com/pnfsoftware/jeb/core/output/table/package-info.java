package com.pnfsoftware.jeb.core.output.table;

interface package-info {
}
