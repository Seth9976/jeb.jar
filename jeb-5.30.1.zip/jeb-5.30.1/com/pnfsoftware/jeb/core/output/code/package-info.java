package com.pnfsoftware.jeb.core.output.code;

interface package-info {
}
