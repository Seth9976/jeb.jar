package com.pnfsoftware.jeb.core.actions;

public interface IActionData {
   Object getValue(String var1);

   void setValue(String var1, Object var2);
}
