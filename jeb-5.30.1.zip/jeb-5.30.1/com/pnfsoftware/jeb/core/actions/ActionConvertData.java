package com.pnfsoftware.jeb.core.actions;

public class ActionConvertData extends ActionData {
}
