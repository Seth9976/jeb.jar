package com.pnfsoftware.jeb.core.actions;

public class ActionDeleteData extends ActionData {
}
