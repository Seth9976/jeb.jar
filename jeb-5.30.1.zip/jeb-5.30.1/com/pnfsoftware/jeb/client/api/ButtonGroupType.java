package com.pnfsoftware.jeb.client.api;

public enum ButtonGroupType {
   OK,
   OK_CANCEL,
   YES_NO,
   YES_NO_CANCEL;
}
