package com.pnfsoftware.jeb.client.api;

public interface IUnitFragmentPositionChangeListener {
   void onUpdate(UnitFragmentPosition var1);
}
