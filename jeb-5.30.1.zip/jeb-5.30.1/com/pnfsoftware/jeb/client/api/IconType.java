package com.pnfsoftware.jeb.client.api;

public enum IconType {
   QUESTION,
   INFORMATION,
   WARNING,
   ERROR;
}
