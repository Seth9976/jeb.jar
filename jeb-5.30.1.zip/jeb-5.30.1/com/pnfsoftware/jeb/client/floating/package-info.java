package com.pnfsoftware.jeb.client.floating;

interface package-info {
}
