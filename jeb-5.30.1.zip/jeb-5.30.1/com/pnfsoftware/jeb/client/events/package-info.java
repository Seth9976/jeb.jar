package com.pnfsoftware.jeb.client.events;

interface package-info {
}
