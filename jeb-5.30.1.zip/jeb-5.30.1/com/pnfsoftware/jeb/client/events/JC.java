package com.pnfsoftware.jeb.client.events;

public enum JC {
   InitializationComplete,
   FocusGained,
   CodeFontChanged,
   ItemStyleChanged;
}
