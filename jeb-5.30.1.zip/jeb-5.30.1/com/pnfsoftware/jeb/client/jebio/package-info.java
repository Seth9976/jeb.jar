package com.pnfsoftware.jeb.client.jebio;

interface package-info {
}
