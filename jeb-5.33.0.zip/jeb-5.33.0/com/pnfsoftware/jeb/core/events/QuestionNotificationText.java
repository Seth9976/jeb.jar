package com.pnfsoftware.jeb.core.events;

public class QuestionNotificationText extends AbstractQuestionNotification {
   public QuestionNotificationText(String var1, String var2) {
      super(var1, var2, false);
   }
}
