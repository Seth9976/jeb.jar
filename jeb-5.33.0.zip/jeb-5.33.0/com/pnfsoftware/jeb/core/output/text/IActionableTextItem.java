package com.pnfsoftware.jeb.core.output.text;

import com.pnfsoftware.jeb.core.output.IActionableItem;

public interface IActionableTextItem extends IActionableItem, IVisualTextItem {
}
