package com.pnfsoftware.jeb.core.output.text;

public interface IAnchor {
   long getIdentifier();

   int getLineIndex();
}
