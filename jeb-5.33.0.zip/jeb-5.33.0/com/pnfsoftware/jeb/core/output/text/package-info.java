package com.pnfsoftware.jeb.core.output.text;

interface package-info {
}
