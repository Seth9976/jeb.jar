package com.pnfsoftware.jeb.core.output.text;

public interface ICoordinates {
   long getAnchorId();

   int getLineDelta();

   int getColumnOffset();
}
