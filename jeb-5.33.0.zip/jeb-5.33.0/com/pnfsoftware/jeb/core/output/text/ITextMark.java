package com.pnfsoftware.jeb.core.output.text;

public interface ITextMark {
   int getOffset();

   String getName();

   Object getObject();
}
