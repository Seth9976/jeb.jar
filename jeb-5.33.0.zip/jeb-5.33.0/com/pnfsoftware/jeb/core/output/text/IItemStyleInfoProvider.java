package com.pnfsoftware.jeb.core.output.text;

import com.pnfsoftware.jeb.core.output.ItemClassIdentifiers;

public interface IItemStyleInfoProvider {
   StyleInfo getStyle(ItemClassIdentifiers var1);
}
