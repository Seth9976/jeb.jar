package com.pnfsoftware.jeb.core.output.tree;

import com.pnfsoftware.jeb.core.output.IVisualItem;

public interface IVisualNode extends IVisualItem, INode {
   int getInitialExpansion();
}
