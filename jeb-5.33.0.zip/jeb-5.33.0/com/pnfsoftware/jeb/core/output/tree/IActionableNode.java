package com.pnfsoftware.jeb.core.output.tree;

import com.pnfsoftware.jeb.core.output.IActionableItem;

public interface IActionableNode extends IActionableItem, IVisualNode {
}
