package com.pnfsoftware.jeb.core.output.table.impl;

interface package-info {
}
