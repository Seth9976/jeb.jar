package com.pnfsoftware.jeb.core.output.table;

import com.pnfsoftware.jeb.core.output.IItem;

public interface ICell extends IItem {
   String getLabel();
}
