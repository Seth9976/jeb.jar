package com.pnfsoftware.jeb.core.output.table;

public interface ICellCoordinates {
   int getRowIndex();

   int getColumnIndex();
}
