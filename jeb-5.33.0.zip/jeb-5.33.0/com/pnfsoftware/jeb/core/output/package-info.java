package com.pnfsoftware.jeb.core.output;

interface package-info {
}
