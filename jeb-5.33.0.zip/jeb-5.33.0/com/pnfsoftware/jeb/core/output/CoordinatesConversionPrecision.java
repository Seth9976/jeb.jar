package com.pnfsoftware.jeb.core.output;

public enum CoordinatesConversionPrecision {
   FIRST,
   BEST,
   LAST;
}
