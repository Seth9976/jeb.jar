package com.pnfsoftware.jeb.core.output.code;

import com.pnfsoftware.jeb.core.output.text.impl.AbstractTextDocument;
import com.pnfsoftware.jeb.util.serialization.annotations.SerDisabled;

@SerDisabled
public abstract class CodeDocument extends AbstractTextDocument {
}
