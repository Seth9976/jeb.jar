package com.pnfsoftware.jeb.core.output.code.coordinates;

interface package-info {
}
