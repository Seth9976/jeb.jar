package com.pnfsoftware.jeb.core.output.code.coordinates;

import com.pnfsoftware.jeb.util.serialization.annotations.Ser;

@Ser
public interface ICodeCoordinates {
   @Override
   String toString();
}
