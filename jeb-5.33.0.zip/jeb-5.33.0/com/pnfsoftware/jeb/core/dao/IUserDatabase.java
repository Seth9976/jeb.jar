package com.pnfsoftware.jeb.core.dao;

public interface IUserDatabase {
}
