package com.pnfsoftware.jeb.core.units.code.android.adb;

// $VF: synthetic class
class AndroidDeviceUtil$1 {
   static {
      try {
         $SwitchMap$com$pnfsoftware$jeb$core$units$code$android$adb$AndroidPlatformABI[AndroidPlatformABI.ARM.ordinal()] = 1;
      } catch (NoSuchFieldError var0) {
      }
   }
}
