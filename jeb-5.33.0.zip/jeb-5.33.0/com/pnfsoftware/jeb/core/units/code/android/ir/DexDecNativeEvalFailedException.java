package com.pnfsoftware.jeb.core.units.code.android.ir;

public class DexDecNativeEvalFailedException extends DexDecEvaluationException {
   private static final long serialVersionUID = 1L;

   public DexDecNativeEvalFailedException() {
   }

   public DexDecNativeEvalFailedException(String var1) {
      super(var1);
   }

   public DexDecNativeEvalFailedException(Throwable var1) {
      super(var1);
   }

   public DexDecNativeEvalFailedException(String var1, Throwable var2) {
      super(var1, var2);
   }
}
