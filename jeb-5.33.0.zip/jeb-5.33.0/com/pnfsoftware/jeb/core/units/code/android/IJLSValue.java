package com.pnfsoftware.jeb.core.units.code.android;

public interface IJLSValue {
   char getTypeTag();

   Object getValue();
}
