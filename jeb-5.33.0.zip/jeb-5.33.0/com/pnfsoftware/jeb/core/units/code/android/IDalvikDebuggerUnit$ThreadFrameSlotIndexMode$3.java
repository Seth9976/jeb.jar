package com.pnfsoftware.jeb.core.units.code.android;

enum IDalvikDebuggerUnit$ThreadFrameSlotIndexMode$3 {
   @Override
   public String toString() {
      return "Variable index (vX)";
   }
}
