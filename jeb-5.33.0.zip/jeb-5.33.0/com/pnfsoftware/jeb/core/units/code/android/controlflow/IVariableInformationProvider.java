package com.pnfsoftware.jeb.core.units.code.android.controlflow;

import com.pnfsoftware.jeb.core.units.code.ICFGOwnerContext;
import com.pnfsoftware.jeb.util.serialization.annotations.Ser;

@Ser
public interface IVariableInformationProvider extends ICFGOwnerContext {
}
