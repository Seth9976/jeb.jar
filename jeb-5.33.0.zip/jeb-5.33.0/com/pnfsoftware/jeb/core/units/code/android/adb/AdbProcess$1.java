package com.pnfsoftware.jeb.core.units.code.android.adb;

// $VF: synthetic class
class AdbProcess$1 {
   static {
      try {
         $SwitchMap$com$pnfsoftware$jeb$core$units$code$android$adb$AdbProcess$Field[AdbProcess.Field.USER.ordinal()] = 1;
      } catch (NoSuchFieldError var2) {
      }

      try {
         $SwitchMap$com$pnfsoftware$jeb$core$units$code$android$adb$AdbProcess$Field[AdbProcess.Field.PID.ordinal()] = 2;
      } catch (NoSuchFieldError var1) {
      }

      try {
         $SwitchMap$com$pnfsoftware$jeb$core$units$code$android$adb$AdbProcess$Field[AdbProcess.Field.NAME.ordinal()] = 3;
      } catch (NoSuchFieldError var0) {
      }
   }
}
