package com.pnfsoftware.jeb.core.units.code.android;

public interface IOptimizedDexUnit {
   IDexUnit getDex();
}
