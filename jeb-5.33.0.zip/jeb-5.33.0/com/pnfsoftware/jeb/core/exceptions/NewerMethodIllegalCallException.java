package com.pnfsoftware.jeb.core.exceptions;

public class NewerMethodIllegalCallException extends JebRuntimeException {
   private static final long serialVersionUID = 1L;
}
