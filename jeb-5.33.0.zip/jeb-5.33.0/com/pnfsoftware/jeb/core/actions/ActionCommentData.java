package com.pnfsoftware.jeb.core.actions;

public class ActionCommentData extends ActionData {
   private String comment;
   private String newComment;

   public String getComment() {
      return this.comment;
   }

   public void setComment(String var1) {
      this.comment = var1;
   }

   public String getNewComment() {
      return this.newComment;
   }

   public void setNewComment(String var1) {
      this.newComment = var1;
   }
}
