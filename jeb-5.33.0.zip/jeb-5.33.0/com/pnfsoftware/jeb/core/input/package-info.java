package com.pnfsoftware.jeb.core.input;

interface package-info {
}
