package com.pnfsoftware.jeb.core.properties;

public interface IPropertyTypePath extends IPropertyTypeString {
}
