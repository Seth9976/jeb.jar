package com.pnfsoftware.jeb.core.properties;

public interface IPropertyTypeBoolean extends IPropertyType {
   Boolean getDefault();
}
