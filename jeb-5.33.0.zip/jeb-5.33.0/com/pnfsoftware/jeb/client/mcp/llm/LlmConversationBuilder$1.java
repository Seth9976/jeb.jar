package com.pnfsoftware.jeb.client.mcp.llm;

// $VF: synthetic class
class LlmConversationBuilder$1 {
   static {
      try {
         $SwitchMap$com$pnfsoftware$jeb$client$mcp$llm$LlmApiType[LlmApiType.OPENAI.ordinal()] = 1;
      } catch (NoSuchFieldError var2) {
      }

      try {
         $SwitchMap$com$pnfsoftware$jeb$client$mcp$llm$LlmApiType[LlmApiType.ANTHROPIC.ordinal()] = 2;
      } catch (NoSuchFieldError var1) {
      }

      try {
         $SwitchMap$com$pnfsoftware$jeb$client$mcp$llm$LlmApiType[LlmApiType.GEMINI.ordinal()] = 3;
      } catch (NoSuchFieldError var0) {
      }
   }
}
