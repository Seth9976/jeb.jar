package com.pnfsoftware.jeb.client.mcp;

import com.fasterxml.jackson.core.type.TypeReference;

class JsonUtil$1 extends TypeReference {
}
