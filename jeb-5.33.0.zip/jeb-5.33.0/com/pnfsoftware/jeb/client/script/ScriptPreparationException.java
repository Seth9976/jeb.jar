package com.pnfsoftware.jeb.client.script;

public class ScriptPreparationException extends ScriptException {
   private static final long serialVersionUID = 1L;

   public ScriptPreparationException(String var1) {
      super(var1);
   }

   public ScriptPreparationException(Throwable var1) {
      super(var1);
   }

   public ScriptPreparationException(String var1, Throwable var2) {
      super(var1, var2);
   }
}
