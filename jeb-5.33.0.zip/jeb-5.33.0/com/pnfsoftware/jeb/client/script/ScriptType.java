package com.pnfsoftware.jeb.client.script;

public enum ScriptType {
   @Deprecated
   JAVA,
   PYTHON;
}
