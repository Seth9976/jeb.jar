package com.pnfsoftware.jeb.client.script;

interface package-info {
}
