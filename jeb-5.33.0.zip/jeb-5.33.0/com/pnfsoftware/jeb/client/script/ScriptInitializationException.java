package com.pnfsoftware.jeb.client.script;

public class ScriptInitializationException extends ScriptException {
   private static final long serialVersionUID = 1L;

   public ScriptInitializationException(Throwable var1) {
      super(var1);
   }
}
