package com.pnfsoftware.jeb.client.telemetry;

interface package-info {
}
