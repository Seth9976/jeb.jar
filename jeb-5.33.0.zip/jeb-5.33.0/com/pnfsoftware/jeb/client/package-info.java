package com.pnfsoftware.jeb.client;

interface package-info {
}
