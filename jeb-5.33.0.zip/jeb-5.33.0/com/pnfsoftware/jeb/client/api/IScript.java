package com.pnfsoftware.jeb.client.api;

public interface IScript {
   void run(IClientContext var1);
}
