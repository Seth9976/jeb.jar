package com.pnfsoftware.jeb.client.api;

interface package-info {
}
